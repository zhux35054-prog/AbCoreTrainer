# AbCoreTrainer

Android 原生腹肌训练 App（Kotlin + Jetpack Compose）。

## 云端构建 APK（仅用手机即可操作）

1. 将本项目全部文件上传到 GitHub 仓库根目录，保留 `.github/workflows/build-apk.yml`。
2. 打开仓库的 **Actions** 页面，选择 **Build Android APK**。
3. 如果首次运行出现 GitHub Actions 权限提示，按页面提示启用 Actions。
4. 构建完成后打开成功的 workflow run，在 **Artifacts** 区域下载 `AbCoreTrainer-debug-apk`。
5. 解压下载的 ZIP，得到 `app-debug.apk`，再在 Android 手机上安装。

也可以在 **Actions → Build Android APK → Run workflow** 手动触发构建。

## 当前工程状态

这是开发中的源码版本，不是已验证的正式发布版。首次云端构建会验证工程能否编译；后台音乐服务、锁屏通知控制和真机行为仍需后续完善与测试。
