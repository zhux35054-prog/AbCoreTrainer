package com.example.abcoretrainer

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.SystemClock
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private data class Drill(val name: String, val rounds: Int, val target: Int, val timed: Boolean, val rest: Int, val hint: String)
private val drills = listOf(
    Drill("死虫式", 2, 15, false, 30, "仰卧，腰背贴近地面；对侧手脚缓慢伸展，再收回。"),
    Drill("支撑抬腿", 3, 15, false, 60, "保持躯干稳定，收紧核心，交替抬腿，避免塌腰。"),
    Drill("仰卧卷腹", 3, 15, false, 60, "下巴微收，肩胛骨离地即可，不要用手拉颈部。"),
    Drill("平板支撑", 2, 60, true, 60, "手肘位于肩膀正下方，头、背、髋保持一条直线。"),
    Drill("侧向支撑（左侧）", 1, 60, true, 15, "左肘撑地，身体侧向成直线，髋部不要下沉。"),
    Drill("侧向支撑（右侧）", 1, 60, true, 60, "右肘撑地，身体侧向成直线，髋部不要下沉。"),
    Drill("拉伸", 2, 60, true, 30, "放松腹部与髋部，缓慢呼吸，不要弹震式拉伸。")
)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var musicVolume: Float = 0.35f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.SIMPLIFIED_CHINESE
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { runOnUiThread { player?.setVolume(musicVolume * 0.22f, musicVolume * 0.22f) } }
                    override fun onDone(utteranceId: String?) { runOnUiThread { player?.setVolume(musicVolume, musicVolume) } }
                    override fun onError(utteranceId: String?) { runOnUiThread { player?.setVolume(musicVolume, musicVolume) } }
                })
            }
        }
        setContent { TrainerScreen(onMusic = { enabled, volume -> musicVolume = volume; setMusic(enabled, volume) }, onSpeak = { speak(it) }) }
    }
    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "trainer-${System.currentTimeMillis()}")
    }
    private fun setMusic(enabled: Boolean, volume: Float) {
        if (enabled) {
            if (player == null) {
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    resources.openRawResourceFd(R.raw.workout_bgm).use { afd ->
                        setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    }
                    isLooping = true
                    prepare()
                }
            }
            player?.setVolume(volume, volume)
            if (player?.isPlaying != true) player?.start()
        } else player?.pause()
    }
    override fun onDestroy() { player?.release(); player = null; tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun TrainerScreen(onMusic: (Boolean, Float) -> Unit, onSpeak: (String) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var round by remember { mutableIntStateOf(1) }
    var seconds by remember { mutableIntStateOf(5) }
    var phase by remember { mutableStateOf("ready") } // ready, work, rest, done
    var running by remember { mutableStateOf(false) }
    var music by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.35f) }
    val drill = drills[index]
    val total = drills.sumOf { it.rounds }
    val completed = drills.take(index).sumOf { it.rounds } + (round - 1)

    fun advanceToNext() {
        if (index < drills.lastIndex) { index += 1; round = 1; phase = "ready"; seconds = 5; running = false }
        else { phase = "done"; running = false; seconds = 0; onSpeak("训练完成，做得很好") }
    }

    LaunchedEffect(running, phase, index, round) {
        if (running && (phase == "ready" || phase == "work" || phase == "rest")) {
            val start = SystemClock.elapsedRealtime()
            val duration = seconds
            while (running && seconds > 0) {
                kotlinx.coroutines.delay(250)
                val left = (duration - ((SystemClock.elapsedRealtime() - start) / 1000)).toInt().coerceAtLeast(0)
                seconds = left
            }
            if (running && seconds == 0) {
                if (phase == "ready") { phase = "work"; seconds = if (drill.timed) drill.target else 0; onSpeak("开始${drill.name}") }
                else if (phase == "work") {
                    if (round < drill.rounds) { round += 1; phase = "rest"; seconds = drill.rest; onSpeak("休息${drill.rest}秒") }
                    else advanceToNext()
                } else { phase = "work"; seconds = if (drill.timed) drill.target else 0; onSpeak("开始${drill.name}") }
            }
        }
    }
    fun begin() {
        if (phase == "ready") { running = true; onSpeak("准备开始，五秒后进入${drill.name}") }
        else running = !running
    }
    fun completeRepSet() {
        if (!drill.timed && phase == "work") {
            if (round < drill.rounds) { round += 1; phase = "rest"; seconds = drill.rest; running = true; onSpeak("本组完成，休息${drill.rest}秒") }
            else advanceToNext()
        }
    }
    fun skip() { advanceToNext() }

    Column(Modifier.fillMaxSize().background(Color(0xFF101820)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("CORE FLOW", color = Color(0xFF79E0C1), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("腹肌训练", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { completed.toFloat() / total }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF79E0C1), trackColor = Color(0xFF34434D))
        Text("进度 ${completed.coerceAtMost(total)} / $total 组 · 第 ${index + 1} / ${drills.size} 项", color = Color.LightGray)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1D2B35)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(when (phase) { "ready" -> "准备动作"; "rest" -> "组间休息"; "done" -> "训练完成"; else -> "正在训练" }, color = Color(0xFF79E0C1), fontSize = 14.sp)
                    Spacer(Modifier.height(14.dp))
                    Text(if (phase == "done") "做得很好！" else drill.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(if (phase == "done") "今天的训练已经结束" else "第 $round / ${drill.rounds} 组", color = Color.LightGray)
                }
                Text(if (phase == "done") "✓" else if (phase == "work" && !drill.timed) "${drill.target} 次" else if (phase == "ready") "%02d".format(seconds) else "%02d:%02d".format(seconds / 60, seconds % 60), color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (phase == "done") "记得放松和补充水分" else drill.hint, color = Color(0xFFD3DEE3), fontSize = 15.sp)
                if (!drill.timed && phase == "work") Button(onClick = { completeRepSet() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF79E0C1), contentColor = Color(0xFF102027))) { Text("完成本组（${drill.target} 次）", fontWeight = FontWeight.Bold) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { if (phase == "ready") begin() else running = !running }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF79E0C1), contentColor = Color(0xFF102027))) { Text(if (phase == "ready") "开始训练" else if (running) "暂停" else "继续") }
            OutlinedButton(onClick = { skip() }, modifier = Modifier.weight(1f)) { Text("跳过此项", color = Color.White) }
            OutlinedButton(onClick = { index = 0; round = 1; seconds = 5; phase = "ready"; running = false }, modifier = Modifier.weight(1f)) { Text("重置", color = Color.White) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("背景音乐", color = Color.White)
            Spacer(Modifier.width(10.dp))
            Switch(checked = music, onCheckedChange = { music = it; onMusic(it, volume) })
            Spacer(Modifier.weight(1f))
            Text("音量", color = Color.LightGray)
            Slider(value = volume, onValueChange = { volume = it; if (music) onMusic(true, it) }, modifier = Modifier.width(130.dp))
        }
    }
    if (phase == "done") { /* terminal state intentionally remains visible */ }

}

