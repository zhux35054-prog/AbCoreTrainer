# 腹肌训练 App（AbCoreTrainer）构建与安装

## 当前状态
这是 Android 原生 Kotlin + Jetpack Compose 工程，包含训练流程第一版和本地原创 BGM。当前交付的是**源码工程**，不是已签名 APK；本工程尚未在 Android SDK 环境完成编译或真机测试。后台播放服务、锁屏通知控制和更完整的动作示意图仍需后续完善。

## 在电脑上构建 APK

1. 在电脑安装最新版稳定版 Android Studio。
2. 解压 `AbCoreTrainer_source.zip`。
3. Android Studio 选择 **Open**，打开解压后的 `AbCoreTrainer` 文件夹（里面应能看到 `settings.gradle.kts`）。
4. 等待 Gradle Sync。若提示安装 Android SDK Platform 35 或 Build Tools，按提示安装；使用 JDK 17 或 Android Studio 自带 JBR。
5. 选择菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
6. 成功后点击右下角提示中的 **locate**。通常 APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。
7. 将 `app-debug.apk` 传到 Android 手机，点击文件安装。若系统提示，允许文件管理器/浏览器“安装未知应用”；只安装自己构建且可信的 APK。

## 手机上安装与使用

当前尚无可直接安装的 APK。拿到 APK 后：
1. 在手机文件管理器找到 `app-debug.apk` 并点击。
2. 按 Android 系统提示允许该来源安装应用，然后完成安装。
3. 打开“腹肌训练”，检查语音播报音量；首次使用需确保系统中文语音服务可用。
4. 可先打开背景音乐开关并调整音量，再点击“开始训练”。
5. 次数型动作完成目标次数后点“完成本组”；计时型动作会自动倒计时。可暂停/继续、跳过或重置。

## 已知限制
- 当前 BGM 由 Activity 持有播放器，退出/销毁 Activity 后不会保证持续播放；后台播放服务尚未完成。
- 训练状态尚未持久化，进程被系统回收后不保证自动恢复。
- “准备/进入下一动作”采用手动开始下一项的第一版流程。
- 动作提示为通用文字提示，不等同于专业教练的动作评估。
- 编译前需要 Android Studio / Android SDK；本次制作环境没有 Gradle 命令和 Android SDK，故不能在此生成或验证 APK。
